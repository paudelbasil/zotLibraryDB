pref("extensions.zotlibupdater.updatepath", "");
